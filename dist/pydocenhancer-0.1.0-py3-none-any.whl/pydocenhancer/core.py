import ast
import inspect
from typing import Dict, List, Optional
import os
import sys
import io
import contextlib

class DocEnhancer:
    def __init__(self, provider: str = "mock", api_key: str = None, model: str = "mock-model", language: str = "en"):
        """
        Initialize PyDocEnhancer with an AI provider.
        :param provider: AI provider ("mock", "openai", "local").
        :param api_key: API key for cloud providers (optional).
        :param model: Model name for LLM (e.g., "llama3.2" for local).
        :param language: Output language for documentation (default: "en").
        """
        self.provider = provider
        self.api_key = api_key
        self.model = model
        self.language = language
        self.llm = None if provider == "mock" else self._init_llm()

    def _init_llm(self):
        """Initialize the LLM client based on provider."""
        if self.provider == "openai":
            from openai import OpenAI
            return OpenAI(api_key=self.api_key)
        elif self.provider == "local":
            from llama_cpp import Llama
            return Llama(model_path=self.model)
        return None

    def _mock_llm(self, text: str, task: str, language: Optional[str] = None) -> str:
        """Mock LLM response for demo purposes."""
        lang = language or self.language
        if task == "summarize":
            return f"[{lang}] Summary of {text[:50]}...: This code performs a specific function."
        elif task == "explain":
            return f"[{lang}] Explanation of {text[:50]}...: This function processes input data."
        elif task == "translate":
            return f"[{lang}] {text}"
        elif task == "example":
            return f"# Example usage in {lang}\n{text}"
        return ""

    def parse_module(self, module_path: str) -> List[Dict]:
        """Parse a Python module and extract function details."""
        with open(module_path, "r") as file:
            code = file.read()
        tree = ast.parse(code)
        functions = []

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                func_name = node.name
                docstring = ast.get_docstring(node) or "No docstring"
                source = inspect.getsource(getattr(inspect.getmodule(node), func_name, None))
                example = self.extract_example_from_docstring(docstring)
                functions.append({
                    "name": func_name,
                    "docstring": docstring,
                    "source": source,
                    "summary": self._mock_llm(docstring, "summarize", self.language),
                    "explanation": self._mock_llm(source, "explain", self.language),
                    "example": example,
                    "example_test_result": self.test_example_code(example) if example else None
                })
        return functions

    def extract_example_from_docstring(self, docstring: str) -> Optional[str]:
        """Extract example code from a docstring if present."""
        # Simple heuristic: look for lines starting with 'Example:' or code blocks
        lines = docstring.splitlines()
        example_lines = []
        in_example = False
        for line in lines:
            if 'Example' in line:
                in_example = True
                continue
            if in_example:
                if line.strip() == '' or line.strip().startswith('>>>'):
                    continue
                if line.strip().startswith('"""') or line.strip().startswith("'''"):
                    break
                example_lines.append(line)
        return '\n'.join(example_lines).strip() if example_lines else None

    def test_example_code(self, code: str) -> str:
        """Run the example code and return the output or error."""
        if not code:
            return "No example to test."
        try:
            # Redirect stdout to capture print output
            stdout = io.StringIO()
            with contextlib.redirect_stdout(stdout):
                exec(code, {})
            return f"Success. Output:\n{stdout.getvalue()}"
        except Exception as e:
            return f"Error: {e}"

    def generate_docs(self, module_path: str, output_dir: str, language: Optional[str] = None) -> None:
        """Generate markdown documentation for a module, optionally in a different language."""
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        lang = language or self.language
        functions = self.parse_module(module_path)
        output_file = os.path.join(output_dir, f"{os.path.basename(module_path)}.{lang}.md")
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(f"# Documentation for {os.path.basename(module_path)} [{lang}]\n\n")
            for func in functions:
                f.write(f"## Function: {func['name']}\n")
                f.write(f"**Docstring**: {self._mock_llm(func['docstring'], 'translate', lang)}\n\n")
                f.write(f"**Summary**: {func['summary']}\n\n")
                f.write(f"**Explanation**: {func['explanation']}\n\n")
                if func['example']:
                    f.write(f"**Example**:\n```python\n{func['example']}\n```\n\n")
                    f.write(f"**Example Test Result**: {func['example_test_result']}\n\n")
                f.write("```python\n" + func['source'] + "\n```\n\n")

    def search_docs(self, query: str, docs_dir: str) -> List[str]:
        """Search documentation using a natural language query (mock implementation)."""
        return [f"Found match for '{query}' in {docs_dir} (mock result)"] 